"""LASSO-based feature selection for small-n materials datasets."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.linear_model import LassoCV
from sklearn.preprocessing import StandardScaler


def select_features_lasso(
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    cv: int = 5,
    min_features: int = 3,
) -> tuple[list[str], LassoCV, StandardScaler]:
    """Fit a cross-validated LASSO and return the subset of features with nonzero
    coefficients, along with the fitted model and scaler (needed to transform new data
    consistently).

    If LASSO zeroes out too many features (fewer than `min_features`), falls back to
    keeping the `min_features` largest-magnitude coefficients so downstream models
    still have enough signal to work with.
    """
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_train)

    lasso = LassoCV(cv=cv, random_state=42, max_iter=10000).fit(X_scaled, y_train)
    coefs = pd.Series(lasso.coef_, index=X_train.columns)
    selected = coefs[coefs.abs() > 1e-8].index.tolist()

    if len(selected) < min_features:
        selected = coefs.abs().sort_values(ascending=False).head(min_features).index.tolist()

    return selected, lasso, scaler
