"""Metrics and plotting utilities."""
from __future__ import annotations

import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    return {
        "MAE": mean_absolute_error(y_true, y_pred),
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "R2": r2_score(y_true, y_pred),
    }


def plot_parity(y_true: np.ndarray, preds: dict[str, np.ndarray], out_path: str) -> None:
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    plt.figure(figsize=(6, 6))
    lims = [min(y_true.min(), *[p.min() for p in preds.values()]),
            max(y_true.max(), *[p.max() for p in preds.values()])]
    plt.plot(lims, lims, "k--", linewidth=1, label="Ideal")
    for name, y_pred in preds.items():
        plt.scatter(y_true, y_pred, alpha=0.7, label=name)
    plt.xlabel("True value")
    plt.ylabel("Predicted value")
    plt.title("Parity plot: predicted vs. true")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def plot_lasso_coefficients(coefs, out_path: str) -> None:
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    coefs_sorted = coefs.reindex(coefs.abs().sort_values(ascending=True).index)
    plt.figure(figsize=(7, 5))
    coefs_sorted.plot(kind="barh")
    plt.xlabel("LASSO coefficient (standardized features)")
    plt.title("Feature importance (LASSO)")
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()
