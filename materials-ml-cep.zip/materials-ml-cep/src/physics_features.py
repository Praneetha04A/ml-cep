"""Physics-informed feature engineering.

Builds descriptors motivated by known solid-state physics relationships that govern
lattice thermal conductivity and related materials properties, rather than relying
solely on raw elemental statistics. Encoding known physics into the feature set is
what lets the downstream models generalize from a small number of samples.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def add_physics_features(df: pd.DataFrame) -> pd.DataFrame:
    """Append physics-informed descriptor columns to a dataframe.

    Expects columns: cation_mass, anion_mass, cation_electroneg, anion_electroneg,
    cation_radius, anion_radius (as produced by src/data_generation.py). If your real
    dataset uses different column names, adjust the mapping below.
    """
    out = df.copy()

    # Average / reduced mass — governs phonon group velocity and Debye frequency.
    out["mass_avg"] = (out["cation_mass"] + out["anion_mass"]) / 2.0
    out["reduced_mass"] = (out["cation_mass"] * out["anion_mass"]) / (
        out["cation_mass"] + out["anion_mass"]
    )
    out["mass_ratio"] = out["cation_mass"] / out["anion_mass"]

    # Electronegativity difference — proxy for bond ionicity / stiffness, which
    # correlates with Debye temperature and phonon scattering strength.
    out["electroneg_diff"] = (out["cation_electroneg"] - out["anion_electroneg"]).abs()

    # Debye-temperature-like proxy: stiffer, lighter lattices -> higher characteristic
    # phonon frequency. theta_D ~ sqrt(k / m); we use electronegativity diff as a
    # bond-stiffness surrogate since force constants aren't directly available.
    bond_stiffness_proxy = out["electroneg_diff"] * 10.0
    out["debye_temp_proxy"] = np.sqrt(bond_stiffness_proxy / out["mass_avg"].clip(lower=1e-6)) * 50.0

    # Size mismatch — larger ionic radius mismatch increases point-defect / mass-disorder
    # phonon scattering (Rayleigh scattering), tending to suppress thermal conductivity.
    out["radius_mismatch"] = (out["cation_radius"] - out["anion_radius"]).abs()
    out["radius_ratio"] = out["cation_radius"] / out["anion_radius"]

    # Approximate Gruneisen-parameter proxy — larger bond anharmonicity (here approximated
    # via electronegativity mismatch) increases Umklapp phonon-phonon scattering.
    out["gruneisen_proxy"] = 1.0 / (1.0 + out["electroneg_diff"])

    return out


PHYSICS_FEATURE_NAMES = [
    "mass_avg",
    "reduced_mass",
    "mass_ratio",
    "electroneg_diff",
    "debye_temp_proxy",
    "radius_mismatch",
    "radius_ratio",
    "gruneisen_proxy",
]
