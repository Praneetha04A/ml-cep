"""Dataset loading and train/test splitting."""
from __future__ import annotations

import pandas as pd
from sklearn.model_selection import train_test_split

from .data_generation import generate_dataset


def load_dataset(path: str | None = None, n_samples: int = 120, seed: int = 42) -> pd.DataFrame:
    """Load a materials dataset.

    If `path` is given, loads a CSV from disk (must contain composition/descriptor
    columns plus a target property column). Otherwise falls back to the synthetic
    chalcogenide generator so the pipeline runs without external data.
    """
    if path:
        return pd.read_csv(path)
    return generate_dataset(n_samples=n_samples, seed=seed)


def split_dataset(df: pd.DataFrame, target: str, test_size: float = 0.2, seed: int = 42):
    """Split a dataframe into train/test feature matrices and target vectors.

    Non-numeric columns (e.g. formula strings) are dropped from the feature matrix
    automatically; keep them in df if you want to inspect predictions by formula.
    """
    y = df[target].values
    X = df.drop(columns=[target]).select_dtypes(include="number")
    return train_test_split(X, y, test_size=test_size, random_state=seed)
