"""Model builders: Kernel Ridge Regression and Gradient Boosting, both tuned via CV."""
from __future__ import annotations

import numpy as np
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.kernel_ridge import KernelRidge
from sklearn.model_selection import GridSearchCV


def build_krr(cv: int = 5) -> GridSearchCV:
    """Kernel Ridge Regression with an RBF kernel, grid-searched over
    regularization strength (alpha) and kernel width (gamma) -- important to tune
    carefully in the small-data regime to avoid over/under-smoothing.
    """
    param_grid = {
        "alpha": np.logspace(-3, 1, 8),
        "gamma": np.logspace(-3, 1, 8),
    }
    model = KernelRidge(kernel="rbf")
    return GridSearchCV(model, param_grid, cv=cv, scoring="neg_mean_absolute_error", n_jobs=-1)


def build_gbr(cv: int = 5) -> GridSearchCV:
    """Gradient Boosting Regressor, grid-searched over depth/learning rate/n_estimators.

    Tree depth and n_estimators are kept modest by default since small datasets are
    prone to overfitting with deep, heavily-boosted ensembles.
    """
    param_grid = {
        "n_estimators": [50, 100, 200],
        "max_depth": [2, 3, 4],
        "learning_rate": [0.01, 0.05, 0.1],
        "subsample": [0.8, 1.0],
    }
    model = GradientBoostingRegressor(random_state=42)
    return GridSearchCV(model, param_grid, cv=cv, scoring="neg_mean_absolute_error", n_jobs=-1)
