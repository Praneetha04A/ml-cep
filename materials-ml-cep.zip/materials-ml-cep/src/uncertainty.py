"""Fisher-information / CRLB-inspired prediction uncertainty.

The Cramer-Rao Lower Bound (CRLB) gives the minimum achievable variance for an
unbiased estimator, computed as the inverse of the Fisher information. For a general
nonparametric regressor (KRR, GBR) there's no closed-form Fisher information matrix
the way there is for a simple parametric model, so this module implements a practical
*approximation*:

1. Estimate residual noise variance (sigma^2) from cross-validated training residuals.
2. For each test point, numerically estimate the local sensitivity of the model's
   prediction to small input perturbations (a numerical Jacobian).
3. Approximate the local Fisher information as J^T J / sigma^2 (as in nonlinear
   least-squares CRLB theory) and invert its scalar projection to obtain an
   approximate lower bound on prediction variance.

This is a heuristic diagnostic -- useful for flagging which predictions fall in
well-sampled, low-sensitivity regions of feature space (low bound, more trustworthy)
versus sparse/high-sensitivity extrapolation regions (high bound, less trustworthy).
It is NOT an exact CRLB for tree ensembles or kernel machines, and should not be
interpreted as calibrated confidence intervals.
"""
from __future__ import annotations

import numpy as np


def estimate_residual_variance(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    residuals = y_true - y_pred
    return float(np.var(residuals, ddof=1)) if len(residuals) > 1 else float(np.var(residuals))


def _numerical_jacobian(predict_fn, X: np.ndarray, eps: float = 1e-4) -> np.ndarray:
    """Compute a numerical Jacobian of predict_fn at each row of X via central differences.

    Returns an array of shape (n_samples, n_features).
    """
    n_samples, n_features = X.shape
    jac = np.zeros((n_samples, n_features))
    base_scale = np.std(X, axis=0)
    base_scale[base_scale == 0] = 1.0

    for j in range(n_features):
        step = eps * base_scale[j]
        X_plus, X_minus = X.copy(), X.copy()
        X_plus[:, j] += step
        X_minus[:, j] -= step
        jac[:, j] = (predict_fn(X_plus) - predict_fn(X_minus)) / (2 * step)
    return jac


def crlb_uncertainty(predict_fn, X_test: np.ndarray, residual_variance: float) -> np.ndarray:
    """Approximate per-sample CRLB-inspired prediction variance lower bound.

    Args:
        predict_fn: callable, model.predict, taking an (n, d) array and returning (n,).
        X_test: (n_samples, n_features) array of test inputs (same scaling as training).
        residual_variance: estimated noise variance (sigma^2) from held-out residuals.

    Returns:
        Array of shape (n_samples,) with an approximate variance lower bound per prediction.
        Larger values indicate the prediction is more sensitive to its inputs locally
        (i.e. less well-constrained by the training data in that region).
    """
    jac = _numerical_jacobian(predict_fn, X_test)
    # Local "information" proxy: squared sensitivity magnitude per sample.
    fisher_info = np.sum(jac ** 2, axis=1) / max(residual_variance, 1e-12)
    fisher_info = np.clip(fisher_info, 1e-12, None)
    # CRLB: variance lower bound = 1 / Fisher information.
    return 1.0 / fisher_info
