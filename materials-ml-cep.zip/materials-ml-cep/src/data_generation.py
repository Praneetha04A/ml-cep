"""
Synthetic small-dataset generator for chalcogenide-like materials.

This is a stand-in for a real experimental/DFT dataset so the pipeline is runnable
out of the box. It generates plausible compositions and elemental descriptors, then
computes a synthetic lattice thermal conductivity target from a physically motivated
(but simplified) functional form plus noise -- mimicking the kind of structure-property
relationship the pipeline is designed to learn from few samples.

Replace this module's output with a real dataset loaded in src/data.py when available.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

# A small set of chalcogen-forming and common counter-cation elements, with
# illustrative atomic mass (amu) and Pauling electronegativity values.
ELEMENTS = {
    "S":  {"mass": 32.06,  "electroneg": 2.58, "radius": 1.04},
    "Se": {"mass": 78.97,  "electroneg": 2.55, "radius": 1.17},
    "Te": {"mass": 127.60, "electroneg": 2.10, "radius": 1.37},
    "Pb": {"mass": 207.20, "electroneg": 2.33, "radius": 1.75},
    "Sn": {"mass": 118.71, "electroneg": 1.96, "radius": 1.45},
    "Bi": {"mass": 208.98, "electroneg": 2.02, "radius": 1.56},
    "Sb": {"mass": 121.76, "electroneg": 2.05, "radius": 1.45},
    "Ag": {"mass": 107.87, "electroneg": 1.93, "radius": 1.44},
    "Cu": {"mass": 63.55,  "electroneg": 1.90, "radius": 1.28},
    "Ge": {"mass": 72.63,  "electroneg": 2.01, "radius": 1.22},
}
CATIONS = ["Pb", "Sn", "Bi", "Sb", "Ag", "Cu", "Ge"]
ANIONS = ["S", "Se", "Te"]


def _synthetic_kappa(cation: str, anion: str, rng: np.random.Generator) -> float:
    """Simplified Slack-model-like functional form for lattice thermal conductivity.

    Real lattice thermal conductivity roughly scales as:
        kappa ~ (M_avg * theta_D^3 * delta) / (gamma^2 * T * n^(2/3))
    We approximate theta_D (Debye temp) via bond stiffness proxy (electronegativity
    difference) and mass, and Gruneisen parameter gamma via electronegativity mismatch
    (larger mismatch -> softer/more anharmonic bonds -> lower kappa), then add noise.
    """
    m_cat, m_an = ELEMENTS[cation]["mass"], ELEMENTS[anion]["mass"]
    en_cat, en_an = ELEMENTS[cation]["electroneg"], ELEMENTS[anion]["electroneg"]
    r_cat, r_an = ELEMENTS[cation]["radius"], ELEMENTS[anion]["radius"]

    m_avg = (m_cat + m_an) / 2.0
    en_diff = abs(en_cat - en_an)
    bond_stiffness_proxy = en_diff * 10.0  # stand-in for force constant
    theta_d_proxy = np.sqrt(bond_stiffness_proxy / m_avg) * 50.0
    gruneisen_proxy = 1.0 + 3.0 / (1.0 + en_diff)  # more mismatch -> softer -> not directly used below
    size_mismatch = abs(r_cat - r_an)

    kappa = (m_avg ** -0.5) * (theta_d_proxy ** 0.5) * (1.0 / (1.0 + size_mismatch)) * 2.5
    kappa *= rng.normal(loc=1.0, scale=0.08)  # measurement/model noise
    return max(kappa, 0.05)


def generate_dataset(n_samples: int = 120, seed: int = 42) -> pd.DataFrame:
    """Generate a small synthetic dataset of binary/pseudo-binary chalcogenides.

    Returns a DataFrame with columns:
        formula, cation, anion, cation_mass, anion_mass, cation_electroneg,
        anion_electroneg, cation_radius, anion_radius, thermal_conductivity
    """
    rng = np.random.default_rng(seed)
    rows = []
    for _ in range(n_samples):
        cation = rng.choice(CATIONS)
        anion = rng.choice(ANIONS)
        kappa = _synthetic_kappa(cation, anion, rng)
        rows.append(
            {
                "formula": f"{cation}{anion}",
                "cation": cation,
                "anion": anion,
                "cation_mass": ELEMENTS[cation]["mass"],
                "anion_mass": ELEMENTS[anion]["mass"],
                "cation_electroneg": ELEMENTS[cation]["electroneg"],
                "anion_electroneg": ELEMENTS[anion]["electroneg"],
                "cation_radius": ELEMENTS[cation]["radius"],
                "anion_radius": ELEMENTS[anion]["radius"],
                "thermal_conductivity": kappa,
            }
        )
    return pd.DataFrame(rows)


if __name__ == "__main__":
    df = generate_dataset()
    print(df.head())
    print(f"\nGenerated {len(df)} synthetic samples.")
