# CEP-Enhanced Machine Learning for Materials Property Prediction on Small Datasets

A data-efficient machine learning pipeline for predicting materials properties (e.g. lattice
thermal conductivity of chalcogenide compounds) when only a small labeled dataset is available.

The pipeline combines:

- **Physics-informed feature engineering** — descriptors derived from known physical
  relationships (Debye temperature scaling, atomic mass/bond-strength ratios, etc.) instead of
  relying purely on data-driven features.
- **Cramér–Rao Lower Bound (CRLB) inspired uncertainty estimation** — approximates the
  Fisher information of the fitted model to flag which predictions are statistically reliable
  given the small-sample regime, and which are extrapolations.
- **LASSO feature selection** — L1-regularized regression used to shrink a wide physics +
  data-driven feature set down to the most informative descriptors, which matters a lot when
  `n_samples` is small relative to `n_features`.
- **Kernel Ridge Regression (KRR)** and **Gradient Boosting Regression (GBR)** — two
  complementary model families (smooth kernel-based vs. tree-based ensemble) trained on the
  selected features, compared via cross-validation.

> **Note on data:** No proprietary dataset was provided alongside the project description, so
> this repo ships with a physically-motivated **synthetic** chalcogenide dataset generator
> (`src/data_generation.py`) so the pipeline runs end-to-end out of the box. Swap in your real
> dataset by replacing `load_dataset()` in `src/data.py` with a loader for your CSV — the rest
> of the pipeline is dataset-agnostic as long as you provide a materials formula/composition and
> a target property column.

## Project structure

```
materials-ml-cep/
├── data/                      # place real datasets here (CSV)
├── src/
│   ├── data.py                 # dataset loading / train-test split
│   ├── data_generation.py      # synthetic chalcogenide dataset (for demo/testing)
│   ├── physics_features.py     # physics-informed descriptor engineering
│   ├── feature_selection.py    # LASSO-based feature selection
│   ├── models.py               # KRR and Gradient Boosting model builders
│   ├── uncertainty.py           # Fisher information / CRLB-inspired uncertainty
│   └── evaluate.py             # metrics + plots
├── main.py                     # end-to-end pipeline entry point
├── requirements.txt
└── README.md
```

## Quickstart

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

python main.py --n-samples 120 --target thermal_conductivity
```

This will:
1. Generate (or load) the dataset.
2. Engineer physics-informed features.
3. Select features via LASSO.
4. Train and cross-validate KRR and Gradient Boosting models.
5. Estimate per-prediction uncertainty from an approximate Fisher information matrix.
6. Print a metrics report and save `results/parity_plot.png` and `results/feature_importance.png`.

## Using your own dataset

Replace the synthetic generator with a CSV loader:

```python
# src/data.py
def load_dataset(path="data/my_materials.csv"):
    import pandas as pd
    df = pd.read_csv(path)
    return df  # must contain a composition column + your target property column
```

Then run:

```bash
python main.py --data data/my_materials.csv --target thermal_conductivity
```

## Method notes

- **Why LASSO before KRR/GBR?** With small-`n` materials datasets, dozens of candidate
  descriptors can easily outnumber samples, causing overfitting. LASSO's L1 penalty drives
  irrelevant coefficients to exactly zero, giving a compact, interpretable feature subset before
  the nonlinear models ever see the data.
- **Why two model families?** KRR assumes smooth similarity-based relationships in feature
  space (good for small, smooth property landscapes); Gradient Boosting captures nonlinear,
  threshold-like interactions between descriptors. Comparing both guards against picking a model
  that's a poor fit for the underlying structure.
- **CRLB-inspired uncertainty:** For each test point we approximate the local Fisher information
  from the model's sensitivity (numerical Jacobian) to its inputs and the residual variance, then
  invert it to get an approximate lower bound on prediction variance. This is a heuristic, not an
  exact CRLB for nonparametric models — see `src/uncertainty.py` docstring for the derivation and
  its limitations.

## License

MIT — see `LICENSE`.
