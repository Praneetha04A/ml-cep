"""End-to-end pipeline: load data -> physics features -> LASSO selection ->
train/compare KRR & Gradient Boosting -> CRLB-inspired uncertainty -> report + plots.
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

from src.data import load_dataset, split_dataset
from src.evaluate import compute_metrics, plot_lasso_coefficients, plot_parity
from src.feature_selection import select_features_lasso
from src.models import build_gbr, build_krr
from src.physics_features import PHYSICS_FEATURE_NAMES, add_physics_features
from src.uncertainty import crlb_uncertainty, estimate_residual_variance


def main():
    parser = argparse.ArgumentParser(description="CEP-enhanced ML for materials property prediction")
    parser.add_argument("--data", type=str, default=None, help="Path to CSV dataset (optional; uses synthetic data if omitted)")
    parser.add_argument("--target", type=str, default="thermal_conductivity", help="Target property column name")
    parser.add_argument("--n-samples", type=int, default=120, help="Number of synthetic samples if --data is not given")
    parser.add_argument("--cv", type=int, default=5, help="Number of cross-validation folds")
    args = parser.parse_args()

    print(f"[1/6] Loading dataset (data={args.data or 'synthetic'})...")
    df = load_dataset(path=args.data, n_samples=args.n_samples)

    print("[2/6] Engineering physics-informed features...")
    df = add_physics_features(df)

    X_train, X_test, y_train, y_test = split_dataset(df, target=args.target)
    print(f"    Train/test sizes: {len(X_train)} / {len(X_test)}")

    print("[3/6] Selecting features with LASSO...")
    selected_features, lasso_model, scaler = select_features_lasso(X_train, y_train, cv=args.cv)
    print(f"    Selected {len(selected_features)} / {X_train.shape[1]} features: {selected_features}")

    X_train_sel = X_train[selected_features].values
    X_test_sel = X_test[selected_features].values

    print("[4/6] Training Kernel Ridge Regression and Gradient Boosting (grid search CV)...")
    krr = build_krr(cv=args.cv).fit(X_train_sel, y_train)
    gbr = build_gbr(cv=args.cv).fit(X_train_sel, y_train)
    print(f"    Best KRR params: {krr.best_params_}")
    print(f"    Best GBR params: {gbr.best_params_}")

    print("[5/6] Evaluating on held-out test set...")
    preds = {"KRR": krr.predict(X_test_sel), "GBR": gbr.predict(X_test_sel)}
    for name, y_pred in preds.items():
        metrics = compute_metrics(y_test, y_pred)
        print(f"    {name}: MAE={metrics['MAE']:.4f}  RMSE={metrics['RMSE']:.4f}  R2={metrics['R2']:.4f}")

    print("[6/6] Estimating CRLB-inspired prediction uncertainty (best model)...")
    best_name = min(preds, key=lambda n: compute_metrics(y_test, preds[n])["MAE"])
    best_model = krr if best_name == "KRR" else gbr
    train_pred = best_model.predict(X_train_sel)
    sigma2 = estimate_residual_variance(y_train, train_pred)
    bounds = crlb_uncertainty(best_model.predict, X_test_sel, sigma2)
    print(f"    Best model: {best_name}")
    print(f"    Mean CRLB-inspired variance bound: {np.mean(bounds):.5f}")
    print(f"    (higher = prediction is less well-constrained by training data)")

    print("\nSaving plots to results/ ...")
    plot_parity(y_test, preds, "results/parity_plot.png")
    lasso_coefs = pd.Series(lasso_model.coef_, index=X_train.columns)
    plot_lasso_coefficients(lasso_coefs, "results/feature_importance.png")

    print("Done. See results/parity_plot.png and results/feature_importance.png")


if __name__ == "__main__":
    main()
